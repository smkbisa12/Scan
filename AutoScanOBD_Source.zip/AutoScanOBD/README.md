# AutoScan OBD

APK OBD-II MVP untuk Android, dibuat native Java.

## Fitur
- Koneksi Bluetooth Classic ke adapter ELM327 yang sudah di-pair.
- Dashboard real-time: RPM, speed, coolant temperature, engine load, voltage.
- Read DTC mode 03.
- Clear DTC mode 04.
- CSV logging.

## Cara build APK
1. Buka folder ini di Android Studio.
2. Tunggu Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK debug ada di `app/build/outputs/apk/debug/app-debug.apk`.

## Cara pakai
1. Pair adapter ELM327 dari Settings Bluetooth Android.
2. Colok ELM327 ke port OBD-II mobil.
3. Kontak ON / mesin hidup.
4. Buka AutoScan OBD, pilih adapter, tekan Connect.

## Batasan teknis
- Fokus ke OBD-II standar engine/powertrain.
- Tidak menjamin akses ABS, SRS/airbag, immobilizer, coding, actuator test, atau modul manufaktur tertentu.
- Adapter ELM327 murah sering memakai clone chip dan responsnya tidak stabil.
