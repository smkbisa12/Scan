package com.autoscan.obd;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public class MainActivity extends Activity {
    private static final int REQ_BT = 1001;
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final List<BluetoothDevice> devices = new ArrayList<>();
    private final AtomicBoolean polling = new AtomicBoolean(false);

    private BluetoothAdapter bluetoothAdapter;
    private BluetoothSocket socket;
    private InputStream in;
    private OutputStream out;
    private BufferedWriter logWriter;
    private boolean logging = false;

    private Spinner deviceSpinner;
    private TextView statusText, rpmText, speedText, coolantText, loadText, voltageText, dtcText, logPathText;
    private Button connectButton, refreshButton, readDtcButton, clearDtcButton, logButton;

    private String lastRpm = "", lastSpeed = "", lastCoolant = "", lastLoad = "", lastVoltage = "";

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        bindViews();
        wireEvents();
        ensurePermissions();
    }

    private void bindViews() {
        deviceSpinner = findViewById(R.id.deviceSpinner);
        statusText = findViewById(R.id.statusText);
        rpmText = findViewById(R.id.rpmText);
        speedText = findViewById(R.id.speedText);
        coolantText = findViewById(R.id.coolantText);
        loadText = findViewById(R.id.loadText);
        voltageText = findViewById(R.id.voltageText);
        dtcText = findViewById(R.id.dtcText);
        logPathText = findViewById(R.id.logPathText);
        connectButton = findViewById(R.id.connectButton);
        refreshButton = findViewById(R.id.refreshButton);
        readDtcButton = findViewById(R.id.readDtcButton);
        clearDtcButton = findViewById(R.id.clearDtcButton);
        logButton = findViewById(R.id.logButton);
    }

    private void wireEvents() {
        refreshButton.setOnClickListener(v -> loadPairedDevices());
        connectButton.setOnClickListener(v -> {
            if (socket != null && socket.isConnected()) disconnect(); else connectSelected();
        });
        readDtcButton.setOnClickListener(v -> readDtc());
        clearDtcButton.setOnClickListener(v -> clearDtc());
        logButton.setOnClickListener(v -> toggleLogging());
    }

    private void ensurePermissions() {
        if (bluetoothAdapter == null) {
            setStatus("Bluetooth tidak tersedia di perangkat ini");
            return;
        }
        if (Build.VERSION.SDK_INT >= 31) {
            List<String> needed = new ArrayList<>();
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.BLUETOOTH_CONNECT);
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.BLUETOOTH_SCAN);
            if (!needed.isEmpty()) {
                requestPermissions(needed.toArray(new String[0]), REQ_BT);
                return;
            }
        } else if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQ_BT);
            return;
        }
        loadPairedDevices();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_BT) loadPairedDevices();
    }

    private void loadPairedDevices() {
        if (!hasBtPermission()) return;
        devices.clear();
        List<String> labels = new ArrayList<>();
        try {
            Set<BluetoothDevice> bonded = bluetoothAdapter.getBondedDevices();
            for (BluetoothDevice d : bonded) {
                devices.add(d);
                labels.add((d.getName() == null ? "Unknown" : d.getName()) + "\n" + d.getAddress());
            }
        } catch (SecurityException e) {
            setStatus("Izin Bluetooth belum diberikan");
        }
        if (labels.isEmpty()) labels.add("Belum ada adapter paired. Pair ELM327 di Settings Bluetooth dulu.");
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, labels);
        deviceSpinner.setAdapter(adapter);
        setStatus(devices.isEmpty() ? "Pair adapter ELM327 terlebih dahulu" : "Pilih adapter lalu Connect");
    }

    private boolean hasBtPermission() {
        if (Build.VERSION.SDK_INT >= 31) return checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
        return true;
    }

    private void connectSelected() {
        if (devices.isEmpty()) { toast("Tidak ada adapter paired"); return; }
        BluetoothDevice device = devices.get(deviceSpinner.getSelectedItemPosition());
        io.execute(() -> {
            try {
                setStatus("Menghubungkan ke " + safeName(device) + "...");
                if (!hasBtPermission()) return;
                socket = device.createRfcommSocketToServiceRecord(SPP_UUID);
                socket.connect();
                in = socket.getInputStream();
                out = socket.getOutputStream();
                initElm327();
                ui.post(() -> connectButton.setText("Disconnect"));
                setStatus("Terhubung: " + safeName(device));
                startPolling();
            } catch (Exception e) {
                disconnectSilently();
                setStatus("Gagal konek: " + e.getMessage());
            }
        });
    }

    private String safeName(BluetoothDevice device) {
        try { return device.getName() == null ? device.getAddress() : device.getName(); }
        catch (SecurityException e) { return "adapter"; }
    }

    private void initElm327() throws IOException, InterruptedException {
        sendCommand("ATZ", 1200);
        sendCommand("ATE0", 200);
        sendCommand("ATL0", 200);
        sendCommand("ATS0", 200);
        sendCommand("ATH0", 200);
        sendCommand("ATSP0", 800);
        sendCommand("0100", 300);
    }

    private void startPolling() {
        polling.set(true);
        io.execute(() -> {
            while (polling.get() && socket != null && socket.isConnected()) {
                try {
                    lastRpm = parseRpm(sendCommand("010C", 160));
                    lastSpeed = parseByteValue(sendCommand("010D", 140), "0D", 1, false);
                    lastCoolant = parseByteValue(sendCommand("0105", 140), "05", 1, true);
                    lastLoad = parseEngineLoad(sendCommand("0104", 140));
                    lastVoltage = parseVoltage(sendCommand("ATRV", 140));

                    ui.post(() -> {
                        rpmText.setText(emptyDash(lastRpm));
                        speedText.setText(emptyDash(lastSpeed) + " km/h");
                        coolantText.setText(emptyDash(lastCoolant) + " °C");
                        loadText.setText(emptyDash(lastLoad) + " %");
                        voltageText.setText(emptyDash(lastVoltage) + " V");
                    });
                    writeLogLine();
                    Thread.sleep(350);
                } catch (Exception e) {
                    setStatus("Polling berhenti: " + e.getMessage());
                    polling.set(false);
                }
            }
        });
    }

    private String emptyDash(String s) { return s == null || s.isEmpty() ? "--" : s; }

    private synchronized String sendCommand(String cmd, long waitMs) throws IOException, InterruptedException {
        if (out == null || in == null) throw new IOException("Belum terhubung");
        drainInput();
        out.write((cmd + "\r").getBytes());
        out.flush();
        Thread.sleep(waitMs);
        StringBuilder sb = new StringBuilder();
        long end = System.currentTimeMillis() + 1200;
        while (System.currentTimeMillis() < end) {
            while (in.available() > 0) {
                int c = in.read();
                if (c == -1) break;
                char ch = (char) c;
                if (ch == '>') return clean(sb.toString());
                sb.append(ch);
            }
            Thread.sleep(20);
        }
        return clean(sb.toString());
    }

    private void drainInput() throws IOException {
        if (in == null) return;
        while (in.available() > 0) in.read();
    }

    private String clean(String raw) {
        return raw.replace("SEARCHING...", "")
                .replace("NO DATA", "")
                .replace("STOPPED", "")
                .replace("?", "")
                .replace("\r", "")
                .replace("\n", "")
                .replace(" ", "")
                .trim().toUpperCase(Locale.US);
    }

    private String parseRpm(String response) {
        byte[] bytes = mode01Bytes(response, "0C");
        if (bytes.length < 2) return "";
        int rpm = ((bytes[0] & 0xFF) * 256 + (bytes[1] & 0xFF)) / 4;
        return String.valueOf(rpm);
    }

    private String parseByteValue(String response, String pid, int byteCount, boolean coolantFormula) {
        byte[] bytes = mode01Bytes(response, pid);
        if (bytes.length < byteCount) return "";
        int v = bytes[0] & 0xFF;
        if (coolantFormula) v -= 40;
        return String.valueOf(v);
    }

    private String parseEngineLoad(String response) {
        byte[] bytes = mode01Bytes(response, "04");
        if (bytes.length < 1) return "";
        int pct = Math.round((bytes[0] & 0xFF) * 100f / 255f);
        return String.valueOf(pct);
    }

    private String parseVoltage(String response) {
        String v = response.replace("V", "");
        if (v.matches("[0-9.]+")) return v;
        return "";
    }

    private byte[] mode01Bytes(String response, String pid) {
        int idx = response.indexOf("41" + pid);
        if (idx < 0) return new byte[0];
        String data = response.substring(idx + 4);
        int pairs = data.length() / 2;
        byte[] bytes = new byte[pairs];
        for (int i = 0; i < pairs; i++) {
            try { bytes[i] = (byte) Integer.parseInt(data.substring(i * 2, i * 2 + 2), 16); }
            catch (Exception e) { return new byte[0]; }
        }
        return bytes;
    }

    private void readDtc() {
        io.execute(() -> {
            try {
                String r = sendCommand("03", 600);
                List<String> codes = parseDtc(r);
                ui.post(() -> dtcText.setText(codes.isEmpty() ? "Tidak ada DTC standar powertrain." : joinCodes(codes)));
            } catch (Exception e) {
                setStatus("Gagal baca DTC: " + e.getMessage());
            }
        });
    }

    private void clearDtc() {
        io.execute(() -> {
            try {
                String r = sendCommand("04", 800);
                ui.post(() -> dtcText.setText("Perintah clear DTC dikirim. Respons: " + r));
            } catch (Exception e) {
                setStatus("Gagal clear DTC: " + e.getMessage());
            }
        });
    }

    private List<String> parseDtc(String response) {
        List<String> outCodes = new ArrayList<>();
        int idx = response.indexOf("43");
        if (idx < 0) return outCodes;
        String data = response.substring(idx + 2);
        for (int i = 0; i + 4 <= data.length(); i += 4) {
            String pair = data.substring(i, i + 4);
            if (pair.equals("0000")) continue;
            try { outCodes.add(decodeDtc(Integer.parseInt(pair, 16))); }
            catch (Exception ignored) { }
        }
        return outCodes;
    }

    private String decodeDtc(int raw) {
        char[] types = {'P', 'C', 'B', 'U'};
        char type = types[(raw & 0xC000) >> 14];
        int d1 = (raw & 0x3000) >> 12;
        int d2 = (raw & 0x0F00) >> 8;
        int d3 = (raw & 0x00F0) >> 4;
        int d4 = raw & 0x000F;
        return String.format(Locale.US, "%c%d%X%X%X", type, d1, d2, d3, d4);
    }

    private String joinCodes(List<String> codes) {
        StringBuilder sb = new StringBuilder();
        for (String c : codes) sb.append(c).append('\n');
        return sb.toString().trim();
    }

    private void toggleLogging() {
        if (!logging) {
            try {
                File dir = getExternalFilesDir("logs");
                if (dir != null && !dir.exists()) dir.mkdirs();
                String name = "obd_log_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".csv";
                File f = new File(dir, name);
                logWriter = new BufferedWriter(new FileWriter(f));
                logWriter.write("time,rpm,speed_kmh,coolant_c,load_pct,voltage_v\n");
                logging = true;
                logButton.setText("Stop CSV Log");
                logPathText.setText("Log: " + f.getAbsolutePath());
            } catch (Exception e) { toast("Gagal mulai log: " + e.getMessage()); }
        } else {
            stopLogging();
        }
    }

    private void writeLogLine() {
        if (!logging || logWriter == null) return;
        try {
            String time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(new Date());
            logWriter.write(time + "," + lastRpm + "," + lastSpeed + "," + lastCoolant + "," + lastLoad + "," + lastVoltage + "\n");
            logWriter.flush();
        } catch (Exception ignored) { }
    }

    private void stopLogging() {
        try { if (logWriter != null) logWriter.close(); } catch (Exception ignored) {}
        logWriter = null;
        logging = false;
        logButton.setText("Start CSV Log");
    }

    private void disconnect() {
        polling.set(false);
        stopLogging();
        disconnectSilently();
        connectButton.setText("Connect");
        setStatus("Terputus");
    }

    private void disconnectSilently() {
        try { if (socket != null) socket.close(); } catch (Exception ignored) {}
        socket = null; in = null; out = null;
    }

    private void setStatus(String s) { ui.post(() -> statusText.setText(s)); }
    private void toast(String s) { ui.post(() -> Toast.makeText(this, s, Toast.LENGTH_SHORT).show()); }

    @Override protected void onDestroy() {
        polling.set(false);
        stopLogging();
        disconnectSilently();
        io.shutdownNow();
        super.onDestroy();
    }
}
